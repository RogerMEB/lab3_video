#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os
import sys

#Importamos el video desde la linea de comandos como input
video = sys.argv[1]

#Para llevar a cabo este ejercicio he usado el siguiente codigo de github para usar un servidor rtsp desde mi maquina.

#https://github.com/aler9/rtsp-simple-server/releases

#Las siguientes lineas eran para iniciar el servidor:
#os.system("cd C:\Users\glori\Downloads\rtsp-simple-server_v0.20.3_windows_amd64")
#os.system("start rtsp-simple-server")
#os.system("cd ..")

#Usando -re en ffmpeg e insertando la direccion rtsp en la que transmitir el video podemos hacer el broadcasting.
#He añadido tambien el -stream_loop para que la reproducción dure hasta que queramos cerrarlo.
os.system("ffmpeg -re -stream_loop -1 -i " + video + " -c copy -f rtsp rtsp://localhost:8554/mystream")

#Mediante el programa vlc que permite reproducir desde una url comprobé que funcionaba.


# In[ ]:




