#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import sys

#Importamos el video desde la linea de comandos como input
video = sys.argv[1]

#En este caso vamos a usar DASH como método de transmisión de video usando bento4.

#En primer lugar usamos el mp4fragment para framentar el video en un fichero mp4.
os.system("mp4fragment " + video + " output_fr.mp4")

#Usando el mp4 fragmentado lo vamos a encriptar, usando la función MPEG-CENC.
#Para que funcione hay que especificarle una llave a los tracks.
#En este caso solo encriptaré el Track 1, el de video, el audio no estará encriptado.
#Obtenemos así un mp4 encriptado.
os.system("""mp4encrypt --method MPEG-CENC --key 1:7f412f0575f44f718259beef56ec7771:0a8d9e58502141c3 
--property 1:KID:2fef8ad812df429783e9bf6e5e493e53  --global-option mpeg-cenc.eme-pssh:true output_fr.mp4 output_en.mp4""")

#Finalmente usamos mp4dash el cual nos genera como en el ejercicio con hls, los segmentos y la playlist para
#retransmitir el video.
os.system("mp4dash output_en.mp4")

#mp4dash encripta el video de forma automatica también, peró así se ven todos los pasos.

