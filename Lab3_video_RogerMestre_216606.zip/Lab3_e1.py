#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import sys

#Importamos el video desde la linea de comandos como input
video = sys.argv[1]

#Usando las herramientas de bento4 ya podriamos usar directamente el siguiente comando para crear el hls:

#os.system("mp42hls " + video)

#Este nos genera directamente los segmentos y la playlist m3u8 encriptada con AES en un directorio.


#Tambien lo podemos hacer con el siguiente comando (que es el que he usado) de ffmpeg.
#He indicado que el tiempo por segmento sea de 2 segundos y la playlist de tipo vod.

os.system("ffmpeg -i " + video + " -hls_time 2 -hls_playlist_type vod -f hls outputhls")

